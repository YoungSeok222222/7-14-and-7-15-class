from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework import status
from django.shortcuts import get_object_or_404

from .serializers import BookListSerializer, BookSerializer, CommentSerializer
from .models import Book, Comment

@api_view(['GET', 'POST'])
def book_list(request):
    # Q 1.
    if request.method=='GET':                               # 만약 요청이 GET이라면
        books = Book.objects.all()                          # 모델에서 Book모델의 정보들을 전부 불러온다.
        serializer = BookListSerializer(books,many=True)    # serializer로 포장(json형태로 변환)한다. 이때에 다른 모든 게시글(여러개의 book)들을 조회해야하기 때문에 may=True를 작성한다.
        return Response(serializer.data)                    # 변환된 데이터를 반환한다.
    # Q 2.
    elif request.method=='POST':                            # 만약 요청이 POST라면
        serializer = BookSerializer(data=request.data)      # serializer는 BookSerializer를 사용하여 생성한다.
        if serializer.is_valid(raise_exception=True):       # 유효성 검사를 통해 유효한지 검증한다.
            serializer.save()                               # 유효성 검사를 통과했다면 데이터를 저장한다.
            return Response(serializer.data, status=status.HTTP_201_CREATED)   # 데이터를 정상적으로 저장하고 난 이후, 201 Created를 띄운다.


    


@api_view(['GET', 'DELETE', 'PUT'])
def book_detail(request, book_pk):
    book = get_object_or_404(Book,pk=book_pk)                # 조회, 삭제, 수정 대상이 존재하지 않는 경우 404 오류 응답 상태 코드를 반환한다.
    # Q 3.
    if request.method=='GET':                                # 만약 요청이 GET이면
        serializer = BookSerializer(book)                    # serializer는 BookSerializer를 사용하여 json으로 변환한다.
        return Response(serializer.data)                     
    # Q 4.
    elif request.method=='DELETE':                           # 요청이 DELETE라면
        book.delete()                                           
        return Response(status=status.HTTP_204_NO_CONTENT)   # 데이터를 삭제하고 No_CONTENT를 띄운다.
    # Q 5.
    elif request.method=='PUT':                              # 요청이 'PUT'이라면 
        serializer = BookSerializer(data=request.data)       # serializer는 BookSerializer를 사용한다.
        if serializer.is_valid(raise_exception=True):        # 만약 해당 수정이 유효한지 유효성 검사를 한다.
            serializer.save()
            return Response(serializer.data)                 # 유효성 검사를 통과했다면, 저장하고 반환한다.




@api_view(['GET'])
def comment_list(request):
    # Q 7.
    comments = Comment.objects.all()                         # 모든 댓글을 조회하기 위해 Comment model을 조회한다.
    serializer = CommentSerializer(comments,many=True)       # serializer를 이용하여 json으로 변환한다. 마찬가지로 모든 댓글들을 조회해야 하기 떄문에 many=True를 사용한다.
    return Response(serializer.data)
  


@api_view(['POST'])
def comment_create(request, book_pk):
    # Q 8.
    book = Book.objects.get(pk=book_pk)                       # 댓글을 만들기 위해, 해당 게시글을 가져와야한다. 따라서 comment_pk가 아닌 book_pk를 받아온다.
    serializer = CommentSerializer(data=request.data)         # 댓글을 생성한다.
    if serializer.is_valid(raise_exception=True):             # 작성한 댓글이 유효하다면 
        serializer.save(book=book)                            # 저장하고, 해당 게시글 또한 불러온다.
        return Response(serializer.data,status=status.HTTP_201_CREATED)
    
    

@api_view(['GET', 'DELETE'])
def comment_detail(request, comment_pk):
    # Q 9.
    comment = get_object_or_404(Comment,pk=comment_pk)        # 댓글을 comment_pk를 이용하여 불러오는데, 만약 해당 댓글이 존재하지 않다면 404 오류 응답 상태 코드를 반환한다.
    if request.method=='GET':
        serializer = CommentSerializer(comment)               
        return Response(serializer.data)
    # Q 10.
    elif request.method=='DELETE':                            # DELETE라면 해당 댓글을 삭제한다.
        comment.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
