from rest_framework import serializers
from .models import Book, Comment


class BookListSerializer(serializers.ModelSerializer):

    class Meta:
        model = Book
        fields = ('id', 'title',)


class CommentSerializer(serializers.ModelSerializer):
    # Q 6.
    
    class Meta:
        model = Comment
        fields = ('id', 'content','created_at', 'updated_at')
        read_only = ('article',)                                # read_only True에 article을 넣어주어 해당  article을 읽어준다.
    


class BookSerializer(serializers.ModelSerializer):
    comment_set = CommentSerializer(many=True, read_only=True)  # many=True 옵션을 사용하여 해당 게시글에 달린 모든 댓글을 불러온다. 또한, read_only=True를 사용하여 데이터를 읽기만 해준다.
    # Q 11.
    comment_count = serializers.IntegerField(source='comment_set.count',read_only=True) # source는 위에 있는 comment_set의 개수를 IntegerField를 사용하여 센다. 또한, read_only=True로 하여 데이터를 읽기만 한다.
    class Meta:
        model = Book
        fields = '__all__'
